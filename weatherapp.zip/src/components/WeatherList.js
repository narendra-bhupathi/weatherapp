import React from 'react'
import { Col} from 'react-bootstrap'
import WeatherCard from './WeatherCard'
import {Redirect,useHistory} from 'react-router-dom';


const WeatherList = ({weathers,allData}) => {

  
    const history = useHistory();
    const onView = (dtVal) => {

        console.log("wlist",dtVal);
        console.log("in val");
        console.log(dtVal,allData);
        history.push({pathname: `/view/${dtVal.split(" ")[0]}`,state: allData,dtval:dtVal});

    }

    console.log("in weather list",allData);

    return (
        
        <div className="showDayDiv">
           {weathers.map(({dt, main, weather,dt_txt}) => (
               
                <Col key={dt}  onClick={() => onView(dt_txt)}>
                <WeatherCard 
                    temp_max={main.temp_max} 
                    temp_min={main.temp_min} 
                    dt={dt} 
                    main={weather[0].main} 
                    icon={weather[0].icon}
                  />
                </Col>
            
           ))} 
        </div>
    )
}

export default WeatherList;