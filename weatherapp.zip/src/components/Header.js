import React from 'react';

function Header(){
    return(
        <div class="header">
        <h1>Weather App</h1>
        </div>
  );
}

export default Header;