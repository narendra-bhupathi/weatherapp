import React from 'react';

const HourCard = (props) => {

  const max_t=Math.floor(parseInt(props.temp_max)-273.15);
  const min_t=Math.floor(parseInt(props.temp_min)-273.15);
  const d = props.dt_txt.split(" ")[0];
  const t = props.dt_txt.split(" ")[1];
  var datearray = d.split("-");
  var nd = datearray[2] + '/' + datearray[1] + '/' + datearray[0];
  return (
    <div className="cardW">
      <img src={`http://openweathermap.org/img/wn/${props.icon}.png`} />
        <h3>{nd}</h3>
        <h3>{t}</h3>
        <h3>HIGH : {max_t}<sup>0</sup> C</h3>
        <h3>LOW : {min_t}<sup>0</sup> C</h3>
    </div>
    
  );
};

export default HourCard;