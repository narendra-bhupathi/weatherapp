import React,{ useEffect }  from 'react';
import WeatherList from './WeatherList';
import City from './City';
import {Redirect,useHistory} from 'react-router-dom';

const Search = (props) => {

    const data = props.location.state;
    const history = useHistory();

    useEffect(() => {
        if(!data){
            history.push('/');
        }
    }, [data])

   
    console.log("weather list input",data?.list)
    const fiveDay=[];
    const UniqueDates=[];
    data?.list?.map(item=>{

        const d=item.dt_txt.split(" ")[0];
        if(!UniqueDates.includes(d)){
            UniqueDates.push(d);
            fiveDay.push(item);
        }

    });
    
    console.log("weather list new five",fiveDay)
    return (
        <div>
        <City city={data.city}/>
        <WeatherList weathers={fiveDay} allData={data?.list}/>
        </div>
        )
}

export default Search;