import React from 'react';

const WeatherCard = (props) => {

  const max_t=Math.floor(parseInt(props.temp_max)-273.15);
  const min_t=Math.floor(parseInt(props.temp_min)-273.15);
  const d = new Date(props.dt * 1000);
  const s = d.getDate()+"/"+(d.getMonth()+1)+"/"+d.getFullYear();
  return (
    <div className="cardW">
      <img src={`http://openweathermap.org/img/wn/${props.icon}.png`} />
        <h3>{s}</h3>
        <h3>HIGH : {max_t}<sup>0</sup> C</h3>
        <h3>LOW : {min_t}<sup>0</sup> C</h3>
    </div>
    
  );
};

export default WeatherCard;