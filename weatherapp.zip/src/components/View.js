import React, { useEffect } from 'react';
import { Col} from 'react-bootstrap'
import HourCard from './HourCard'
import {Redirect,useHistory} from 'react-router-dom';

const View = (props) => {
    
    const history = useHistory();
    
    const data = props.location.state;
    const dt_txt=props.location.dtval;

    const filt=dt_txt?.split(" ")[0];
    console.log(filt);
    const oneDay=[];
    data?.map(item=>{

        const filtItem=item.dt_txt.split(" ")[0];
        if(filtItem==filt){
            //console.log(s,sc)
            oneDay.push(item);
        }
    });

    useEffect(() => {
        if(!data){
            history.push('/');
        }
    }, [data])
    
    console.log("oneDay",oneDay);
    return(
        
        <div className="showDayDiv">
           {oneDay.map(({dt, main, weather,dt_txt}) => (
               
                <Col key={dt}>
                <HourCard 
                    dt_txt={dt_txt}
                    temp_max={main.temp_max} 
                    temp_min={main.temp_min} 
                    dt={dt} 
                    main={weather[0].main} 
                    icon={weather[0].icon}
                  />
                </Col>
            
           ))} 
        </div>
    );
}

export default View;
