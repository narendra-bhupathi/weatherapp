export const API_KEY = "06414a02038c537c67836dc0a9c0b6c4";
export const API_BASE_URL = 'http://api.openweathermap.org/';